import React, { Component } from 'react';
//import axios from 'axios';
import moneyicon from './money.svg';
import './App.css';

import Income from './components/Income.js'
import Bills from './components/Bills'
import Purchases from './components/Purchases'


class App extends Component {
  constructor(props){
    super(props)
    this.state = {
      balance: 0
    }
  }

  handleClick(props){
    this.setState({balance: })
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={moneyicon} className="App-logo" alt="logo" />
          <h1 className="App-title">Personal Budget App</h1>
        </header>
          
          <Income/> 
          <button onClick={(e)=>this.handleClick(Income.income)}>Submit</button>

          <Bills/>
          <Purchases/>
          <h2>Balance:{this.state.balance}</h2>
        <footer className='Footer'>icon created by https://creativemarket.com/Becris</footer>
      </div>
    )
  }
}

export default App;
