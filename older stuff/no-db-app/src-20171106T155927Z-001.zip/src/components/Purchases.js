import React, {Component} from 'react'
//import axios from 'axios';


class Purchases extends Component{
    constructor(){
      super()
      this.state={
        purchases: ''
      }
    }
handleChange(value){
      this.setState({purchases: value})
}

render(){
    return(
        <div className='Input'>
            <h2>Purchases</h2>
            <input onChange={(e)=>this.handleChange(e.target.value)}
                type='number'
                name='purchases'
                placeholder='Enter purchases here'
                value={this.state.purchases}/>
            <button>Submit</button>
        </div>
        )
    }
}

export default Purchases